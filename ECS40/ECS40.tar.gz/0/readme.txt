1. no
2. no
3. no
4. no
5. no
6. no
7. yes

